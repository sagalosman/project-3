const port = 8000

module.exports = {
  port
}
